CREATE TABLE admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    nama_petugas VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);
INSERT INTO admin (nama_petugas, username, password) VALUES ('Petugas Parkir', 'admin', 'admin123');
CREATE TABLE tabel_parkir (
    id_parkir INT AUTO_INCREMENT PRIMARY KEY,
    nomor_plat VARCHAR(20) NOT NULL,
    jenis_kendaraan ENUM('Roda 2', 'Roda 4') NOT NULL, 
    waktu_masuk DATETIME NOT NULL,
    waktu_keluar DATETIME NULL,
    status ENUM('Belum', 'Selesai') DEFAULT 'Belum',
    total_bayar INT(11) DEFAULT 0
);
