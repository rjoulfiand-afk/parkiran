<?php
date_default_timezone_set('Asia/Jakarta'); // Wajib biar jam parkirnya akurat WIB!
$koneksi = new mysqli("localhost", "root", "", "db_parkir_pintar");
if ($koneksi->connect_error) die("Koneksi Error: " . $koneksi->connect_error);
?>