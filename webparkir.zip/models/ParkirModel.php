<?php
class ParkirModel {
    private $db;
    public function __construct($koneksi) { $this->db = $koneksi; }
    public function getParkirAktif() {
        return $this->db->query("SELECT * FROM tabel_parkir WHERE status = 'Belum' ORDER BY waktu_masuk DESC");
    }
    public function getLaporanHarian($tanggal) {
        return $this->db->query("SELECT * FROM tabel_parkir WHERE DATE(waktu_masuk) = '$tanggal' ORDER BY waktu_masuk DESC");
    }
    public function getPendapatanHariIni($tanggal) {
        $hasil = $this->db->query("SELECT SUM(total_bayar) as total FROM tabel_parkir WHERE DATE(waktu_keluar) = '$tanggal' AND status = 'Selesai'");
        $data = $hasil->fetch_assoc();
        return $data['total'] ? $data['total'] : 0;
    }
    public function catatMasuk($plat, $jenis, $waktu_masuk) {
        $plat = strtoupper(mysqli_real_escape_string($this->db, $plat));
        return $this->db->query("INSERT INTO tabel_parkir (nomor_plat, jenis_kendaraan, waktu_masuk, status) 
                                 VALUES ('$plat', '$jenis', '$waktu_masuk', 'Belum')");
    }
    public function cariKendaraanKeluar($plat) {
        $plat = strtoupper(mysqli_real_escape_string($this->db, $plat));
        $hasil = $this->db->query("SELECT * FROM tabel_parkir WHERE nomor_plat LIKE '%$plat%' AND status = 'Belum'");
        return $hasil->fetch_assoc(); 
    }
    public function prosesKeluar($id_parkir, $waktu_keluar, $total_bayar) {
        $id = (int)$id_parkir;
        $bayar = (int)$total_bayar;
        return $this->db->query("UPDATE tabel_parkir 
                                 SET waktu_keluar = '$waktu_keluar', status = 'Selesai', total_bayar = $bayar 
                                 WHERE id_parkir = $id");
    }
}
?>
