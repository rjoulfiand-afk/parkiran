<?php
class AdminModel {
    private $db;
    public function __construct($koneksi) { $this->db = $koneksi; }
    public function login($username, $password) {
        $username = mysqli_real_escape_string($this->db, $username);
        $hasil = $this->db->query("SELECT * FROM admin WHERE username='$username' AND password='$password'");
        return $hasil->fetch_assoc();
    }
}
?>