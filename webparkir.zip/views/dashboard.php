<?php 
if(session_status()===PHP_SESSION_NONE) session_start();
if(!isset($_SESSION['id_admin'])) { header("Location: index.php"); exit; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Dashboard Parkir</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">
    <?php include 'views/layout/navbar.php'; ?>           
    <div class="container">
        <?php if(isset($_GET['pesan']) &&$_GET['pesan']=='welcome'): ?>
            <script>Swal.fire({toast:true, position:'top-end', icon:'success', title:'Halo <?php echo $_SESSION['nama_petugas']; ?>!', text:'selamat datang.', showConfirmButton:false, timer:1000});</script>
        <?php endif; ?>
        <div class="row g-2 mb-4">
            <div class="col-md-6">
                <div class="card bg-primary text-black border-0 shadow rounded-2 p-3 d-flex flex-row align-items-center">
                    <div>
                        <h6 class="text-uppercase fw-bold mb-1">Kendaraan Yang Parkir</h6>
                        <h2 class="m-0 fw-bold"><?php echo $kendaraan_aktif->num_rows; ?> Unit</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-success text-white border-0 shadow rounded-2 p-3 d-flex flex-row align-items-center">

                    <div>
                        <h6 class="text-uppercase fw-bold mb-1">Pendapatan Hari Ini</h6>
                        <h2 class="m-0 fw-bold">Rp <?php echo number_format($pendapatan,0,',','.'); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>




