<?php 
if(session_status()===PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Parkir Masuk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">
    <?php include 'views/layout/navbar.php'; ?>
    <div class="container">
        <?php if(isset($_GET['pesan']) &&$_GET['pesan']=='sukses_masuk'): ?>
            <script>Swal.fire('berhasil masuk!', 'Data masuk kendaraan direkam. Silakan masuk.', 'success');</script>
        <?php endif; ?>
        <div class="card border-0 shadow-lg mx-auto rounded-4 p-5" style="max-width: 500px;">
            <h3 class="fw-bold mb-4 text-success text-center"></i>Catat Kendaraan Masuk</h3>
            <form action="index.php?page=parkir_masuk" method="POST">
                <div class="mb-4">
                    <label class="form-label fw-bold small text-muted">Nomor Plat Kendaraan</label>
                    <input type="text" name="nomor_plat" class="form-control form-control-lg bg-light border-0 fw-bold text-uppercase" placeholder="plat nomor" required>
                </div>
                <div class="mb-4">
                    <label class="form-label fw-bold small text-muted">Jenis Kendaraan</label>
                    <select name="jenis_kendaraan" class="form-select form-select-lg bg-light border-0 fw-bold" required>
                        <option value="Roda 2">Motor Roda 2</option>
                        <option value="Roda 4">Mobil Roda 4</option>
                        <option value="Roda 3">becak Roda 3</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success btn-lg w-100 fw-bold rounded-pill shadow">SIMPAN TIKET</button>
            </form>
        </div>
    </div>
</body>
</html>