<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm py-3 mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php?page=dashboard">
            </i>E-Parkir
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navP">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navE">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo ($_GET['page']=='dashboard'?'active fw-bold':''); ?>" href="index.php?page=dashboard">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-success <?php echo ($_GET['page']=='parkir_masuk'?'active fw-bold':''); ?>" href="index.php?page=parkir_masuk">
                        <i class="fa-solid fa-arrow-right-to-bracket me-1"></i> Parkir Masuk
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-danger <?php echo ($_GET['page']=='parkir_keluar'?'active fw-bold':''); ?>" href="index.php?page=parkir_keluar">
                        <i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Parkir Keluar
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo ($_GET['page']=='laporan'?'active fw-bold':''); ?>" href="index.php?page=laporan">Laporan Harian</a>
                </li>
            </ul>
            <span class="text-white-50 me-3">Petugas: <strong class="text-white"><?php echo $_SESSION['nama_petugas']; ?></strong></span>
            <button onclick="konfirmasiKeluar()" class="btn btn-warning btn-sm rounded-pill px-3 fw-bold shadow-sm text-dark">Keluar</button>
        </div>
    </div>
</nav>
<script>
function konfirmasiKeluar() {
    Swal.fire({
        title: 'Keluar Aplikasi?',
        text: "Anda Wajib login lagi!",
        showCancelButton: true,
        confirmButtonColor: 'rgb(0, 0, 0)', cancelButtonColor: '#058aff',
        confirmButtonText: 'Ya, Keluar', cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "index.php?page=logout";
        }
    })
}
</script>