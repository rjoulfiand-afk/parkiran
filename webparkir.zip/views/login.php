<!DOCTYPE html>
<html lang="id">
<head>
    <title>Sistem Parkir - Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>body{background:#0000;}</style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
    <div class="card border-0 shadow-lg p-5 rounded-4" style="width: 400px;">
        <div class="text-center mb-4">
            <h1 class="display-3 text-warning"><i class="fa-solid fa-square-parking"></i></h1>
            <h3 class="fw-bold text-dark">PETUGAS PARKIR</h3>
            <p class="text-muted small">Login Admin Parkir</p>
        </div>
        <form action="index.php?page=login" method="POST">
            <input type="text" name="username" class="form-control form-control-lg bg-light border-0 mb-3" placeholder="Username" required>
            <input type="password" name="password" class="form-control form-control-lg bg-light border-0 mb-4" placeholder="Password" required>
            <button type="submit" class="btn btn-dark btn-lg w-100 fw-bold rounded-pill">LOGIN</button>
        </form>
    </div>
    <?php if(isset($_GET['pesan']) &&$_GET['pesan']=='gagal'): ?>
        <script>Swal.fire('Akses tidak bisa!', 'sandi salah.', 'error');</script>
    <?php endif; ?>
</body>
</html>