<?php 
if(session_status()===PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Parkir Keluar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">
    <?php include 'views/layout/navbar.php'; ?>
    <div class="container">
        <?php if(isset($_GET['pesan']) &&$_GET['pesan']=='sukses_keluar'): ?>
            <script>fire('Transaksi Selesai!', 'Pembayaran diterima. Gerbang keluar dibuka.', 'success');</script>
        <?php endif; ?>
        <div class="card border-0 shadow-lg mx-auto rounded-4 p-5 mb-4" style="max-width: 600px;">
            <h3 class="fw-bold mb-4 text-danger text-center"></i>Pencarian Kendaraan Keluar</h3>
            <form action="index.php" method="GET">
                <input type="hidden" name="page" value="parkir_keluar">
                <div class="input-group input-group-lg shadow-sm">
                    <input type="text" name="cari_plat" class="form-control border-1 bg-light text-uppercase fw-bold" placeholder="Ketik Plat Nomor..." required>
                    <button type="submit" class="btn btn-danger fw-bold px-3">cari</button>
                </div>
            </form>
        </div>
        <?php if(isset($_GET['cari_plat'])): ?>
            <?php if($kendaraan): ?>
                <div class="card border-0 shadow-sm mx-auto rounded-4 p-5" style="max-width: 600px;">
                    <h4 class="fw-bold border-bottom pb-3 mb-4">Rincian Tagihan Parkir</h4>
                    <div class="row mb-1">
                        <div class="col-5 text-muted fw-bold">No. Plat</div>
                        <div class="col-7 fw-bold fs-5 text-dark"><?php echo $kendaraan['nomor_plat']; ?></div>
                    </div>
                    <div class="row mb-1">
                        <div class="col-5 text-muted fw-bold">Jenis</div>
                        <div class="col-7"><span class="badge bg-secondary"><?php echo $kendaraan['jenis_kendaraan']; ?></span></div>
                    </div>
                    <div class="row mb-1">
                        <div class="col-5 text-muted fw-bold">Waktu Masuk</div>
                        <div class="col-7 fw-semibold"><?php echo date('d/m/Y H:i', strtotime($kendaraan['waktu_masuk'])); ?></div>
                    </div>
                    <div class="row mb-1">
                        <div class="col-5 text-muted fw-bold">Durasi Parkir</div>
                        <div class="col-7 text-danger fw-bold"><?php echo $durasi_jam; ?> Jam</div>
                    </div>
                    <div class="row mt-4 pt-3 border-top">
                        <div class="col-5 text-muted fw-bold fs-5">Total Bayar</div>
                        <div class="col-9 fw-bold display-8 text-success">Rp <?php echo number_format($tagihan,0,',','.'); ?></div>
                    </div>
                    <form action="index.php?page=parkir_keluar" method="POST" class="mt-4">
                        <input type="hidden" name="id_parkir" value="<?php echo $kendaraan['id_parkir']; ?>">
                        <input type="hidden" name="waktu_keluar" value="<?php echo $waktu_keluar; ?>">
                        <input type="hidden" name="total_bayar" value="<?php echo $tagihan; ?>">
                        <button type="submit" class="btn btn-success display-5 btn-lg w-70 fw-bold rounded-pill shadow">TERIMA UANG & SELESAI</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="alert alert-danger mx-auto text-dark fw-bold rounded-4 shadow-sm" style="max-width: 400px;"><br>
                    Kendaraan plat "<?php echo strtoupper($_GET['cari_plat']); ?>" tidak ditemukan atau sudah keluar!
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</body>
</html>