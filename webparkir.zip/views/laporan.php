<?php 
if(session_status()===PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Laporan Harian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-light">
    <?php include 'views/layout/navbar.php'; ?>
    <div class="container">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-3 d-flex justify-content-between align-items-center">
                <form action="index.php" method="GET" class="d-flex align-items-center gap-3">
                    <input type="hidden" name="page" value="laporan">
                    <label class="fw-bold text-muted mb-0">Pilih Tanggal:</label>
                    <input type="date" name="tanggal" class="form-control" value="<?php echo $tanggal; ?>" required>
                    <button type="submit" class="btn btn-primary fw-bold px-3">Filter</button>
                </form>
                <a href="index.php?page=cetak_pdf&tanggal=<?php echo $tanggal; ?>" target="_blank" class="btn btn-danger fw-bold rounded-pill px-4 shadow-sm">
                    </i> unduh pdf
                </a>
            </div>
        </div>
        <div class="card border-0 shadow-sm rounded-3 p-3">
            <h4 class="fw-bold mb-3 text-center">Rekap Parkir: <?php echo date('d M Y', strtotime($tanggal)); ?></h4>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>No. Plat</th>
                            <th>Jenis</th>
                            <th>Waktu Masuk</th>
                            <th>Waktu Keluar</th>
                            <th>Status</th>
                            <th>Nominal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no=1; while($row =$data_laporan->fetch_assoc()): ?>
                        <tr class="text-center">
                            <td><?php echo $no++; ?></td>
                            <td class="fw-bold text-primary"><?php echo $row['nomor_plat']; ?></td>
                            <td><?php echo $row['jenis_kendaraan']; ?></td>
                            <td><?php echo date('H:i', strtotime($row['waktu_masuk'])); ?></td>
                            <td><?php echo $row['waktu_keluar'] ? date('H:i', strtotime($row['waktu_keluar'])) : '-'; ?></td>
                            <td>
                                <?php if($row['status']=='Selesai') echo '<span class="badge bg-success">Selesai</span>';
                                      else echo '<span class="badge bg-warning text-dark">Belum Keluar</span>'; ?>
                            </td>
                            <td class="fw-bold text-success">
                                <?php echo $row['total_bayar'] > 0 ? 'Rp '.number_format($row['total_bayar'],0,',','.') : '-'; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <tr class="table-light">
                            <td colspan="6" class="text-end fw-bold fs-7 text-dark">TOTAL PENDAPATAN:</td>
                            <td class="text-center fw-bold fs-5 text-success">Rp <?php echo number_format($total_pendapatan,0,',','.'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</body>
</html>