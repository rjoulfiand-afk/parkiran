<?php
require_once 'models/ParkirModel.php';
class ParkirController {
    private $model;
    public function __construct($koneksi) { $this->model = new ParkirModel($koneksi); }
    public function dashboard() {
        $tgl_hari_ini = date('Y-m-d');$kendaraan_aktif = $this->model->getParkirAktif();$pendapatan = $this->model->getPendapatanHariIni($tgl_hari_ini);
        require_once 'views/dashboard.php';
    }
    public function parkir_masuk() {
        if($_SERVER['REQUEST_METHOD'] == 'POST') {$plat = $_POST['nomor_plat'];$jenis = $_POST['jenis_kendaraan'];$waktu_masuk = date('Y-m-d H:i:s'); // Rekam jam persis pas tombol diklik

            $this->model->catatMasuk($plat, $jenis,$waktu_masuk);
            header("Location: index.php?page=parkir_masuk&pesan=sukses_masuk"); exit;
        }
        require_once 'views/parkir_masuk.php';
    }
    public function parkir_keluar() {
        $kendaraan = null;
        $tagihan = 0;
        $waktu_keluar = date('Y-m-d H:i:s');$durasi_jam = 0;
        if(isset($_GET['cari_plat'])) {$kendaraan = $this->model->cariKendaraanKeluar($_GET['cari_plat']);
            if($kendaraan) {
                $masuk = strtotime($kendaraan['waktu_masuk']);
                $keluar = strtotime($waktu_keluar);
                $selisih_detik = $keluar -$masuk;
                $durasi_jam = ceil($selisih_detik / 3600);
                if($durasi_jam < 1)$durasi_jam = 1; 
                $tarif_dasar = ($kendaraan['jenis_kendaraan'] == 'Roda 2') ? 2000 : 5000;
                $tambahan = 0;
                if($durasi_jam > 2) {$tambahan = ($durasi_jam - 2) * 1000;
                }$tagihan = $tarif_dasar +$tambahan;
            }
        }
        if($_SERVER['REQUEST_METHOD'] == 'POST') {
            $this->model->prosesKeluar($_POST['id_parkir'], $_POST['waktu_keluar'],$_POST['total_bayar']);
            header("Location: index.php?page=parkir_keluar&pesan=sukses_keluar"); exit;
        }
        require_once 'views/parkir_keluar.php';
    }
    public function laporan() {
        $tanggal = isset($_GET['tanggal']) ?$_GET['tanggal'] : date('Y-m-d');
        $data_laporan =$this->model->getLaporanHarian($tanggal);$total_pendapatan = $this->model->getPendapatanHariIni($tanggal);
        
        require_once 'views/laporan.php';
    }
    public function cetak_pdf() {
        $tanggal =$_GET['tanggal'];
        $data_laporan =$this->model->getLaporanHarian($tanggal);$total_pendapatan = $this->model->getPendapatanHariIni($tanggal);
        require_once 'views/cetak_pdf.php';
    }
}
?>